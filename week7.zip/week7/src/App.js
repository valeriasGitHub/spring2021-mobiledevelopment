
import './App.css';
import laps from './components/laps';
import sitUps from './components/sit-ups';

function App() {
  return (
    <div>
      <h1>Exercise Tracker:</h1>
      <laps/>
      <sitUps/>
    </div>
    
  );
}


export default App;
